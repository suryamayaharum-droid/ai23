# ROADMAP INDUSTRIAL

## Fase A — já implementada
Production DB, CineGraph, workers, scheduler, asset URIs, provenance, review, telemetry, plugin SDK e bridges.

## Fase B
- UI web de produção/dailies.
- Adapter real para ComfyUI/OpenCue.
- ACES/OCIO presets do Harum.
- DINOv2/SAM2/CoTracker QC assistido.
- WhisperX transcript/caption worker.
- OpenTimelineIO master timeline.
- publicação por conectores autorizados.

## Fase C
- virtual production/previs 3D com OpenUSD + Blender.
- materiais via MaterialX.
- asset manager compatível com OpenAssetIO.
- render farm OpenCue se houver múltiplos nós permanentes.
- analytics de custo/tempo/qualidade por engine.
