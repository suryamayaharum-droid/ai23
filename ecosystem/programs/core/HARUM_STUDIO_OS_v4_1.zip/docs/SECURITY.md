# SECURITY & COMPUTE POLICY

- Nenhum worker pode usar credenciais embutidas no repositório.
- Nenhuma rotina cria contas, contorna quota, usa hardware sem autorização ou explora provedor.
- Free compute é oportunístico, nunca tratado como recurso garantido.
- Render jobs são idempotentes e pequenos: perder um runtime não perde o filme.
- Hashes e provenance evitam confusão entre versões.
- Segredos devem entrar apenas por environment variables/secret stores.
