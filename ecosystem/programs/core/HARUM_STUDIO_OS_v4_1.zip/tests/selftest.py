import tempfile, pathlib, json, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from harumstudio.db import StudioDB
from harumstudio.bootstrap import bootstrap
from harumstudio.scheduler import Scheduler
from harumstudio.assets import asset_uri
from harumstudio.cinegraph import topological

def run():
    with tempfile.TemporaryDirectory() as td:
        dbp=pathlib.Path(td)/"studio.db"
        snap=bootstrap(dbp)
        assert snap["projects"]==1 and snap["shots"]==6 and snap["tasks"]==18
        db=StudioDB(dbp)
        jobs=Scheduler(db).dispatch()
        assert len(jobs)>=1
        assert asset_uri("HARUM NOIR","frame","face",1).startswith("harum://")
        ordered=topological([
          {"id":"a","depends_on":[]},{"id":"b","depends_on":["a"]},{"id":"c","depends_on":["b"]}
        ])
        assert [x["id"] for x in ordered]==["a","b","c"]
        db.close()
    print("SELFTEST PASS")
if __name__=="__main__": run()
