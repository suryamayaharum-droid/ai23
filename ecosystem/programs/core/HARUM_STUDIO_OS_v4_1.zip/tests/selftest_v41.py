import pathlib, tempfile, sys, json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from harumstudio.router import DecisionEngine
from harumstudio.continuity import ContinuityMemory
from harumstudio.experiments import ExperimentRegistry
from harumstudio.publisher import package_channel

def run():
    root=pathlib.Path(__file__).resolve().parents[1]
    eng=DecisionEngine(root/"config"/"engine_scores.json")
    assert eng.rank("still_motion",0)[0]["engine"]=="ffmpeg_motion"
    with tempfile.TemporaryDirectory() as td:
        td=pathlib.Path(td)
        c=ContinuityMemory(td/"continuity.json"); c.set_canon("hair","chin-length black bob")
        assert c.data["canon"]["hair"]=="chin-length black bob"
        x=ExperimentRegistry(td/"exp.jsonl"); x.record("ffmpeg_motion","still_motion",{},{"score":0.8})
        assert x.best("still_motion")["engine"]=="ffmpeg_motion"
    print("V4.1 SELFTEST PASS")
if __name__=="__main__": run()
