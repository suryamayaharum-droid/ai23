"""
OpenUSD planning manifest.
For 2D/AI productions this stores the intent to bind shot camera/look layers to USD later.
"""
def shot_usd_layers(shot_id):
    return {
      "root":f"{shot_id}.usda",
      "layers":[f"{shot_id}.camera.usda",f"{shot_id}.look.usda",f"{shot_id}.lighting.usda"],
      "purpose":"future 3D/previs interoperability"
    }
