"""
AYON workflow manifest bridge.
Produces a simple node graph that can be translated into AYON workflow nodes.
"""
def scene_to_ayon(graph):
    return {
      "name":graph.get("scene_id","harum-scene"),
      "nodes":[{"id":t["id"],"type":t["kind"],"department":t["department"],"depends_on":t.get("depends_on",[])}
               for t in graph["tasks"]]
    }
