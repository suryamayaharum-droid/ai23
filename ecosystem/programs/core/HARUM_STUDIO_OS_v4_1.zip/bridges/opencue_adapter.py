"""
OpenCue adapter manifest.
This generates a neutral job description that can later be translated to PyOutline/OpenCue REST.
It never assumes an OpenCue server exists.
"""
import json
def build_opencue_job(project, scene_id, shots):
    return {
      "name":f"{project}_{scene_id}",
      "show":project,
      "layers":[
        {"name":s["shot_id"],"command":s.get("command"),"cores":s.get("cores",2),
         "memory_gb":s.get("memory_gb",8),"tags":s.get("tags",[])}
        for s in shots
      ]
    }
