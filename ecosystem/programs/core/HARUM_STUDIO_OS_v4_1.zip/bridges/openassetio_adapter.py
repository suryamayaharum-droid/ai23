"""
Harum URI resolver shaped to migrate toward OpenAssetIO.
"""
from urllib.parse import urlparse, parse_qs
def parse_harum_uri(uri):
    u=urlparse(uri)
    if u.scheme!="harum": raise ValueError("not a harum URI")
    return {"project":u.netloc,"path":u.path.strip("/").split("/"),"query":parse_qs(u.query)}
