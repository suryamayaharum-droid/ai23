"""
Optional Ray bridge. If ray is installed, maps shot functions to remote tasks.
"""
def available():
    try:
        import ray
        return True
    except Exception:
        return False

def start(address=None):
    import ray
    return ray.init(address=address or None, ignore_reinit_error=True)
