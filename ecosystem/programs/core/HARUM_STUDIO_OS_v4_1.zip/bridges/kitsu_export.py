"""
Export production state to a Kitsu-friendly neutral JSON.
No server credentials are stored here.
"""
import json
def export_project(db, project_id):
    p=dict(db.conn.execute("SELECT * FROM projects WHERE id=?",(project_id,)).fetchone())
    seq=[dict(x) for x in db.conn.execute("SELECT * FROM sequences WHERE project_id=?",(project_id,))]
    return {"production":p,"sequences":seq}
