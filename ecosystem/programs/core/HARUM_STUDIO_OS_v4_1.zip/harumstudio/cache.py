from __future__ import annotations
import hashlib, shutil, json
from pathlib import Path

class ContentCache:
    def __init__(self,root):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def key(self,*parts):
        h=hashlib.sha256()
        for p in parts: h.update(str(p).encode()); h.update(b"\0")
        return h.hexdigest()
    def put(self,key,path):
        src=Path(path); dst=self.root/key[:2]/key
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst); return dst
    def get(self,key):
        p=self.root/key[:2]/key
        return p if p.exists() else None
