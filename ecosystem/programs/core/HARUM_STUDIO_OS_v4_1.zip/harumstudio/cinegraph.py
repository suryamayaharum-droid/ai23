from __future__ import annotations
import json

DEPARTMENTS={
 "development":["story","research"],
 "art":["lookdev","reference","concept"],
 "previs":["previs","shot_design","camera"],
 "motion":["portrait_motion","i2v","lipsync","tracking"],
 "editorial":["edit","timeline","subtitles"],
 "sound":["tts","foley","mix"],
 "color":["grade","aces"],
 "qc":["technical_qc","continuity_qc","license_qc"],
 "distribution":["package","metadata","publish"],
}

def topological(tasks):
    by={t["id"]:t for t in tasks}
    deps={t["id"]:set(t.get("depends_on",[])) for t in tasks}
    out=[]
    while deps:
        ready=sorted(k for k,v in deps.items() if not v)
        if not ready: raise ValueError("cycle in task graph")
        for k in ready:
            out.append(by[k]); deps.pop(k)
        for v in deps.values(): v.difference_update(ready)
    return out

def scene_graph(scene):
    shots=scene["shots"]
    tasks=[]
    prev=None
    for s in shots:
        sid=s["shot_id"]
        a=f"{sid}:prep"; b=f"{sid}:render"; c=f"{sid}:qc"
        tasks.append({"id":a,"department":"previs","kind":"shot_design","depends_on":[] if prev is None else [prev]})
        tasks.append({"id":b,"department":"motion","kind":s["task"],"depends_on":[a]})
        tasks.append({"id":c,"department":"qc","kind":"technical_qc","depends_on":[b]})
        prev=c
    tasks.append({"id":f'{scene["scene_id"]}:edit',"department":"editorial","kind":"edit","depends_on":[prev] if prev else []})
    tasks.append({"id":f'{scene["scene_id"]}:sound',"department":"sound","kind":"mix","depends_on":[f'{scene["scene_id"]}:edit']})
    tasks.append({"id":f'{scene["scene_id"]}:masterqc',"department":"qc","kind":"continuity_qc","depends_on":[f'{scene["scene_id"]}:sound']})
    tasks.append({"id":f'{scene["scene_id"]}:package',"department":"distribution","kind":"package","depends_on":[f'{scene["scene_id"]}:masterqc']})
    return {"scene_id":scene["scene_id"],"tasks":tasks}
