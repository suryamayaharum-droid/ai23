from __future__ import annotations
import importlib.util
from pathlib import Path

class PluginRegistry:
    def __init__(self): self.plugins={}
    def register(self,name,obj): self.plugins[name]=obj
    def discover(self, folder):
        for p in Path(folder).glob("*.py"):
            if p.name.startswith("_"): continue
            spec=importlib.util.spec_from_file_location(f"harum_plugin_{p.stem}",p)
            mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            if hasattr(mod,"register"): mod.register(self)
        return self
