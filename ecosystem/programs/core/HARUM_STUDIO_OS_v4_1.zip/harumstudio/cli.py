from __future__ import annotations
import argparse, json
from pathlib import Path
from .bootstrap import bootstrap
from .db import StudioDB
from .scheduler import Scheduler

def main():
    ap=argparse.ArgumentParser(prog="harum-studio")
    sp=ap.add_subparsers(dest="cmd",required=True)
    b=sp.add_parser("bootstrap"); b.add_argument("--db",default="runtime/studio.db"); b.add_argument("--project",default="HARUM NOIR")
    s=sp.add_parser("status"); s.add_argument("--db",default="runtime/studio.db")
    d=sp.add_parser("dispatch"); d.add_argument("--db",default="runtime/studio.db")
    e=sp.add_parser("events"); e.add_argument("--db",default="runtime/studio.db"); e.add_argument("--limit",type=int,default=20)
    a=ap.parse_args()
    if a.cmd=="bootstrap":
        print(json.dumps(bootstrap(a.db,a.project),indent=2))
    else:
        db=StudioDB(a.db)
        if a.cmd=="status": print(json.dumps(db.snapshot(),indent=2))
        elif a.cmd=="dispatch": print(json.dumps(Scheduler(db).dispatch(),default=str,indent=2))
        elif a.cmd=="events":
            rows=db.conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?",(a.limit,)).fetchall()
            print(json.dumps([dict(r) for r in rows],indent=2))
        db.close()
if __name__=="__main__": main()
