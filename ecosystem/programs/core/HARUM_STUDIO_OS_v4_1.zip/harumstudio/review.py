from __future__ import annotations
import json, subprocess, shutil
from pathlib import Path

def contact_sheet(video, out, every=3.0, cols=4, width=320):
    if not shutil.which("ffmpeg"): raise RuntimeError("ffmpeg required")
    vf=f"fps=1/{every},scale={width}:-1,tile={cols}x0:padding=6:margin=6"
    subprocess.run(["ffmpeg","-y","-i",str(video),"-vf",vf,"-frames:v","1",str(out)],check=True)
    return str(out)

def review_packet(video, out_json, notes=None):
    p=Path(video)
    packet={"media":str(p),"exists":p.exists(),"notes":notes or [],"decision":"pending"}
    Path(out_json).write_text(json.dumps(packet,ensure_ascii=False,indent=2),encoding="utf-8")
    return packet
