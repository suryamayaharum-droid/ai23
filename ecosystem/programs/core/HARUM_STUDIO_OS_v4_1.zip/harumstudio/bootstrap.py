from __future__ import annotations
import json
from pathlib import Path
from .db import StudioDB

DEPARTMENTS=[
 "Development & Story","Art & Lookdev","Previs & Camera","Motion & Generative",
 "Editorial","Sound","Color","QC & Continuity","Production","Distribution",
 "R&D","Infrastructure","Rights & Provenance"
]

def bootstrap(db_path, project_name="HARUM NOIR"):
    db=StudioDB(db_path)
    pid=db.create_project(project_name)
    seq=db.create_sequence(pid,"S01","Harum Noir — Season 01")
    scn=db.create_scene(seq,"SC001","23:17","A linha para antes de virar excesso.")
    specs=[
      ("SH010","anchor","still_motion",2.8,"ffmpeg_motion"),
      ("SH020","presence","portrait_motion",3.0,None),
      ("SH030","gesture","i2v",3.5,None),
      ("SH040","detail","depth",2.4,"video_depth_anything"),
      ("SH050","transformation","i2v",4.0,None),
      ("SH060","residue","still_motion",2.5,"ffmpeg_motion"),
    ]
    last=None
    for code,role,task,dur,engine in specs:
        sid=db.create_shot(scn,code,role,task,dur,engine)
        prep=db.create_task(sid,"Previs & Camera","shot_design",gpu=False,dependencies=[last] if last else [])
        render=db.create_task(sid,"Motion & Generative",task,gpu=task in {"i2v","portrait_motion"},min_vram=8,dependencies=[prep])
        qc=db.create_task(sid,"QC & Continuity","technical_qc",gpu=False,dependencies=[render])
        last=qc
    for name,kind,caps,vram in [
      ("CPU-LOCAL","local_cpu",["shot_design","still_motion","depth","technical_qc","edit","mix","package"],0),
      ("GPU-OPTIONAL","local_gpu",["portrait_motion","i2v","lipsync","segmentation","tracking","interpolate","upscale"],16),
    ]: db.add_worker(name,kind,caps,vram)
    db.event("studio.bootstrap","project",pid,{"departments":DEPARTMENTS})
    snap=db.snapshot(); db.close()
    return snap
