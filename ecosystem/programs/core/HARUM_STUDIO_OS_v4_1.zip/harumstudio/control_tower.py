from __future__ import annotations
import json, sqlite3
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
from pathlib import Path

HTML="""<!doctype html><html><head><meta charset="utf-8"><title>HARUM Studio Control Tower</title>
<style>body{font-family:system-ui;background:#0b0b0b;color:#eee8dc;margin:32px}h1{font-weight:500}
.card{border:1px solid #3a352c;padding:16px;margin:12px 0;background:#161616;border-radius:12px}
small{color:#b58a3a}pre{white-space:pre-wrap}</style></head>
<body><h1>HARUM STUDIO OS <small>Control Tower</small></h1><div id="app">loading…</div>
<script>
async function get(p){return await (await fetch(p)).json()}
async function boot(){
 const s=await get('/api/status'), ev=await get('/api/events');
 document.getElementById('app').innerHTML=
 `<div class=card><h2>Factory</h2><pre>${JSON.stringify(s,null,2)}</pre></div>`+
 `<div class=card><h2>Latest events</h2><pre>${JSON.stringify(ev,null,2)}</pre></div>`;
} boot(); setInterval(boot,5000);
</script></body></html>"""

def counts(conn):
    out={}
    for t in ["projects","sequences","scenes","shots","tasks","assets","versions","workers","jobs","events"]:
        try: out[t]=conn.execute(f"select count(*) from {t}").fetchone()[0]
        except Exception: pass
    return out

def serve(db_path,host="127.0.0.1",port=8787):
    db_path=str(Path(db_path).resolve())
    class H(BaseHTTPRequestHandler):
        def send_json(self,obj):
            data=json.dumps(obj,ensure_ascii=False).encode()
            self.send_response(200); self.send_header("Content-Type","application/json; charset=utf-8")
            self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
        def do_GET(self):
            p=urlparse(self.path).path
            if p=="/":
                data=HTML.encode(); self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8")
                self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
            conn=sqlite3.connect(db_path); conn.row_factory=sqlite3.Row
            try:
                if p=="/api/status": self.send_json(counts(conn))
                elif p=="/api/events":
                    rows=conn.execute("select * from events order by id desc limit 30").fetchall()
                    self.send_json([dict(x) for x in rows])
                elif p=="/api/jobs":
                    rows=conn.execute("select * from jobs order by created_at desc limit 100").fetchall()
                    self.send_json([dict(x) for x in rows])
                else: self.send_error(404)
            finally: conn.close()
    print(f"http://{host}:{port}")
    ThreadingHTTPServer((host,port),H).serve_forever()
