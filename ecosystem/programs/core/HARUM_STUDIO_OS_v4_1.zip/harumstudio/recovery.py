from __future__ import annotations
from datetime import datetime, timezone, timedelta

def recover_stale_jobs(db, max_minutes=90):
    cutoff=datetime.now(timezone.utc)-timedelta(minutes=max_minutes)
    rows=db.conn.execute("SELECT * FROM jobs WHERE status IN ('leased','running')").fetchall()
    recovered=[]
    for r in rows:
        ts=r["started_at"] or r["created_at"]
        try: dt=datetime.fromisoformat(ts)
        except Exception: continue
        if dt < cutoff:
            db.conn.execute("UPDATE jobs SET status='failed', ended_at=?, error=? WHERE id=?",
                            (datetime.now(timezone.utc).isoformat(),"stale_job_recovered",r["id"]))
            db.conn.execute("UPDATE tasks SET status='ready' WHERE id=?",(r["task_id"],))
            if r["worker_id"]:
                db.conn.execute("UPDATE workers SET status='idle' WHERE id=?",(r["worker_id"],))
            recovered.append(r["id"])
    db.conn.commit()
    return recovered
