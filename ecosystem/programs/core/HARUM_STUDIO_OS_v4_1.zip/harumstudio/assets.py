from __future__ import annotations
import hashlib, json
from pathlib import Path
from .db import uid, now

def sha256(path, chunk=1024*1024):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        while True:
            b=f.read(chunk)
            if not b: break
            h.update(b)
    return h.hexdigest()

def asset_uri(project, kind, name, version=1):
    safe=lambda s: str(s).strip().replace(" ","_").replace("/","_")
    return f"harum://{safe(project)}/{safe(kind)}/{safe(name)}?v={int(version)}"

def register_asset(db, project, kind, name, path=None, version=1, canonical=False,
                   license_status="review", metadata=None):
    aid=uid("ast")
    uri=asset_uri(project,kind,name,version)
    digest=sha256(path) if path and Path(path).exists() else None
    db.conn.execute("""INSERT OR REPLACE INTO assets
        (id,uri,kind,version,sha256,path,canonical,license_status,metadata,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (aid,uri,kind,int(version),digest,str(path) if path else None,int(canonical),
         license_status,json.dumps(metadata or {},ensure_ascii=False),now()))
    db.conn.commit()
    db.event("asset.registered","asset",aid,{"uri":uri,"sha256":digest})
    return uri

def resolve_asset(db, uri):
    r=db.conn.execute("SELECT * FROM assets WHERE uri=?",(uri,)).fetchone()
    return dict(r) if r else None
