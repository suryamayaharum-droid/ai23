from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone

class ExperimentRegistry:
    def __init__(self,path):
        self.path=Path(path); self.rows=[]
        if self.path.exists():
            self.rows=[json.loads(x) for x in self.path.read_text(encoding="utf-8").splitlines() if x.strip()]
    def record(self,engine,task,settings,metrics,asset=None):
        row={"ts":datetime.now(timezone.utc).isoformat(),"engine":engine,"task":task,
             "settings":settings,"metrics":metrics,"asset":asset}
        with self.path.open("a",encoding="utf-8") as f:f.write(json.dumps(row,ensure_ascii=False)+"\n")
        self.rows.append(row); return row
    def best(self,task,metric="score"):
        xs=[x for x in self.rows if x["task"]==task and metric in x["metrics"]]
        return max(xs,key=lambda x:x["metrics"][metric]) if xs else None
