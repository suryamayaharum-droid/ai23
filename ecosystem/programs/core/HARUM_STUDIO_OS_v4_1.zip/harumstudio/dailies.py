from __future__ import annotations
import html, json
from pathlib import Path

def make_dailies_index(items,out):
    cards=[]
    for x in items:
        cards.append(f"""<article><h3>{html.escape(x.get('shot',''))}</h3>
        <p>{html.escape(x.get('status',''))}</p>
        <code>{html.escape(x.get('media',''))}</code>
        <p>{html.escape(x.get('notes',''))}</p></article>""")
    page=f"""<!doctype html><meta charset=utf-8><title>Harum Dailies</title>
    <style>body{{font-family:system-ui;background:#101010;color:#eee8dc;max-width:1000px;margin:auto}}
    article{{padding:16px;border-bottom:1px solid #333}}code{{color:#b58a3a}}</style>
    <h1>HARUM DAILIES</h1>{''.join(cards)}"""
    Path(out).write_text(page,encoding="utf-8"); return out
