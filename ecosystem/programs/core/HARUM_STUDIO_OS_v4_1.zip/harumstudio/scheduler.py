from __future__ import annotations
import json
from .db import uid, now

class Scheduler:
    def __init__(self, db):
        self.db=db
    def _workers(self):
        return [dict(r) for r in self.db.conn.execute("SELECT * FROM workers WHERE status='idle'").fetchall()]
    def _compatible(self, task, worker):
        caps=set(json.loads(worker["capabilities"]))
        if task["kind"] not in caps and "*" not in caps: return False
        if task["requires_gpu"] and worker["vram_gb"] < task["min_vram_gb"]: return False
        if task["provider"] and task["provider"] not in {worker["kind"],"any"}: return False
        return True
    def plan(self):
        assignments=[]
        workers=self._workers()
        for task in self.db.list_ready_tasks():
            matches=[w for w in workers if self._compatible(task,w)]
            matches.sort(key=lambda w:(w["vram_gb"], w["name"]))
            if matches:
                assignments.append((task,matches[0]))
                workers.remove(matches[0])
        return assignments
    def dispatch(self):
        jobs=[]
        for task,worker in self.plan():
            jid=uid("job")
            self.db.conn.execute("""INSERT INTO jobs(id,task_id,worker_id,status,attempt,created_at)
                                    VALUES(?,?,?,?,?,?)""",
                                 (jid,task["id"],worker["id"],"leased",task["attempts"]+1,now()))
            self.db.conn.execute("UPDATE tasks SET status='leased', attempts=attempts+1 WHERE id=?",(task["id"],))
            self.db.conn.execute("UPDATE workers SET status='busy', last_seen=? WHERE id=?",(now(),worker["id"]))
            self.db.conn.commit()
            self.db.event("job.leased","job",jid,{"task_id":task["id"],"worker":worker["name"]})
            jobs.append({"job_id":jid,"task":task,"worker":worker})
        return jobs
