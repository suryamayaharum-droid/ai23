from __future__ import annotations
import sqlite3, json, uuid
from pathlib import Path
from datetime import datetime, timezone

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS projects(
 id TEXT PRIMARY KEY, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sequences(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 code TEXT NOT NULL, title TEXT, UNIQUE(project_id,code)
);
CREATE TABLE IF NOT EXISTS scenes(
 id TEXT PRIMARY KEY, sequence_id TEXT NOT NULL REFERENCES sequences(id) ON DELETE CASCADE,
 code TEXT NOT NULL, title TEXT, premise TEXT, status TEXT NOT NULL DEFAULT 'planned',
 UNIQUE(sequence_id,code)
);
CREATE TABLE IF NOT EXISTS shots(
 id TEXT PRIMARY KEY, scene_id TEXT NOT NULL REFERENCES scenes(id) ON DELETE CASCADE,
 code TEXT NOT NULL, role TEXT, task TEXT, duration REAL NOT NULL DEFAULT 3,
 status TEXT NOT NULL DEFAULT 'planned', engine TEXT, output_path TEXT,
 seed INTEGER, priority INTEGER NOT NULL DEFAULT 50,
 UNIQUE(scene_id,code)
);
CREATE TABLE IF NOT EXISTS tasks(
 id TEXT PRIMARY KEY, shot_id TEXT NOT NULL REFERENCES shots(id) ON DELETE CASCADE,
 department TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ready',
 attempts INTEGER NOT NULL DEFAULT 0, provider TEXT,
 requires_gpu INTEGER NOT NULL DEFAULT 0, min_vram_gb REAL NOT NULL DEFAULT 0,
 dependency_ids TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS assets(
 id TEXT PRIMARY KEY, uri TEXT UNIQUE NOT NULL, kind TEXT NOT NULL,
 version INTEGER NOT NULL DEFAULT 1, sha256 TEXT, path TEXT,
 canonical INTEGER NOT NULL DEFAULT 0,
 license_status TEXT NOT NULL DEFAULT 'review',
 metadata TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS versions(
 id TEXT PRIMARY KEY, shot_id TEXT NOT NULL REFERENCES shots(id) ON DELETE CASCADE,
 asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE RESTRICT,
 version_number INTEGER NOT NULL, qc_status TEXT NOT NULL DEFAULT 'pending',
 notes TEXT, created_at TEXT NOT NULL,
 UNIQUE(shot_id,version_number)
);
CREATE TABLE IF NOT EXISTS reviews(
 id TEXT PRIMARY KEY, version_id TEXT NOT NULL REFERENCES versions(id) ON DELETE CASCADE,
 decision TEXT NOT NULL, notes TEXT, reviewer TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workers(
 id TEXT PRIMARY KEY, name TEXT UNIQUE NOT NULL, kind TEXT NOT NULL,
 capabilities TEXT NOT NULL, vram_gb REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'idle', last_seen TEXT
);
CREATE TABLE IF NOT EXISTS jobs(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
 worker_id TEXT REFERENCES workers(id) ON DELETE SET NULL,
 status TEXT NOT NULL DEFAULT 'queued', attempt INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, started_at TEXT, ended_at TEXT, error TEXT,
 artifact_path TEXT
);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
 topic TEXT NOT NULL, entity_type TEXT, entity_id TEXT, payload TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_events_topic ON events(topic);
"""

def now():
    return datetime.now(timezone.utc).isoformat()

def uid(prefix):
    return prefix + "_" + uuid.uuid4().hex[:12]

class StudioDB:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
    def close(self): self.conn.close()
    def event(self, topic, entity_type=None, entity_id=None, payload=None):
        self.conn.execute("INSERT INTO events(ts,topic,entity_type,entity_id,payload) VALUES(?,?,?,?,?)",
                          (now(),topic,entity_type,entity_id,json.dumps(payload or {},ensure_ascii=False)))
        self.conn.commit()
    def create_project(self, name):
        pid=uid("prj")
        self.conn.execute("INSERT INTO projects VALUES(?,?,?,?)",(pid,name,"active",now()))
        self.conn.commit(); self.event("project.created","project",pid,{"name":name}); return pid
    def create_sequence(self, project_id, code, title=None):
        sid=uid("seq")
        self.conn.execute("INSERT INTO sequences VALUES(?,?,?,?)",(sid,project_id,code,title))
        self.conn.commit(); return sid
    def create_scene(self, sequence_id, code, title, premise=""):
        sid=uid("scn")
        self.conn.execute("INSERT INTO scenes VALUES(?,?,?,?,?,?)",(sid,sequence_id,code,title,premise,"planned"))
        self.conn.commit(); return sid
    def create_shot(self, scene_id, code, role, task, duration, engine=None, priority=50):
        sid=uid("sht")
        self.conn.execute("INSERT INTO shots(id,scene_id,code,role,task,duration,engine,priority) VALUES(?,?,?,?,?,?,?,?)",
                          (sid,scene_id,code,role,task,float(duration),engine,int(priority)))
        self.conn.commit(); return sid
    def create_task(self, shot_id, department, kind, provider=None, gpu=False, min_vram=0, dependencies=None):
        tid=uid("tsk")
        self.conn.execute("""INSERT INTO tasks(id,shot_id,department,kind,provider,requires_gpu,min_vram_gb,dependency_ids)
                           VALUES(?,?,?,?,?,?,?,?)""",
                          (tid,shot_id,department,kind,provider,int(gpu),float(min_vram),
                           json.dumps(dependencies or [])))
        self.conn.commit(); return tid
    def add_worker(self, name, kind, capabilities, vram_gb=0):
        existing=self.conn.execute("SELECT id FROM workers WHERE name=?",(name,)).fetchone()
        if existing: return existing["id"]
        wid=uid("wrk")
        self.conn.execute("INSERT INTO workers VALUES(?,?,?,?,?,?,?)",
                          (wid,name,kind,json.dumps(capabilities),float(vram_gb),"idle",now()))
        self.conn.commit(); return wid
    def list_ready_tasks(self):
        rows=self.conn.execute("""SELECT t.*, s.code shot_code, s.priority
                                  FROM tasks t JOIN shots s ON s.id=t.shot_id
                                  WHERE t.status='ready' ORDER BY s.priority DESC""").fetchall()
        out=[]
        for r in rows:
            deps=json.loads(r["dependency_ids"])
            if not deps:
                out.append(dict(r)); continue
            q="SELECT COUNT(*) c FROM tasks WHERE id IN (%s) AND status!='done'" % ",".join("?"*len(deps))
            if self.conn.execute(q,deps).fetchone()["c"]==0: out.append(dict(r))
        return out
    def snapshot(self):
        def count(t): return self.conn.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"]
        return {t:count(t) for t in ["projects","sequences","scenes","shots","tasks","assets","versions","reviews","workers","jobs","events"]}
