from __future__ import annotations
import json, time, os
from pathlib import Path
from contextlib import contextmanager

class Telemetry:
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def log(self,event,**fields):
        rec={"ts":time.time(),"event":event,**fields}
        with self.path.open("a",encoding="utf-8") as f: f.write(json.dumps(rec,ensure_ascii=False)+"\n")
    @contextmanager
    def span(self,name,**fields):
        t=time.time(); self.log("span.start",name=name,**fields)
        try:
            yield
            self.log("span.end",name=name,status="ok",elapsed=time.time()-t,**fields)
        except Exception as e:
            self.log("span.end",name=name,status="error",elapsed=time.time()-t,error=repr(e),**fields)
            raise
