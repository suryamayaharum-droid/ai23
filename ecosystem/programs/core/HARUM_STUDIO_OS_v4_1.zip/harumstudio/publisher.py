from __future__ import annotations
import json, shutil
from pathlib import Path

def package_channel(master, outdir, channel, title, description, tags=None, thumbnail=None):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    media=out/Path(master).name
    if Path(master).resolve()!=media.resolve(): shutil.copy2(master,media)
    metadata={"channel":channel,"title":title,"description":description,"tags":tags or [],
              "media":media.name,"thumbnail":Path(thumbnail).name if thumbnail else None,
              "status":"ready_for_authorized_publisher"}
    if thumbnail: shutil.copy2(thumbnail,out/Path(thumbnail).name)
    (out/"metadata.json").write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding="utf-8")
    return metadata
