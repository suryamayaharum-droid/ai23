from __future__ import annotations
import json, time

class EventBus:
    def __init__(self, db): self.db=db
    def emit(self, topic, payload=None, entity_type=None, entity_id=None):
        self.db.event(topic,entity_type,entity_id,payload)
    def tail(self, after_id=0, limit=100):
        rows=self.db.conn.execute("SELECT * FROM events WHERE id>? ORDER BY id LIMIT ?",(after_id,limit)).fetchall()
        return [{**dict(r),"payload":json.loads(r["payload"])} for r in rows]
