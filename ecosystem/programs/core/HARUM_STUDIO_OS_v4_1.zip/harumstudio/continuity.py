from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone

class ContinuityMemory:
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.path.exists(): self.data=json.loads(self.path.read_text(encoding="utf-8"))
        else: self.data={"schema":"harum.continuity/1","canon":{},"scenes":{},"updated_at":None}
    def save(self):
        self.data["updated_at"]=datetime.now(timezone.utc).isoformat()
        self.path.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding="utf-8")
    def set_canon(self,key,value):
        self.data["canon"][key]=value; self.save()
    def scene(self,scene_id):
        return self.data["scenes"].setdefault(scene_id,{"facts":{},"shots":{},"open_loops":[]})
    def fact(self,scene_id,key,value):
        self.scene(scene_id)["facts"][key]=value; self.save()
    def shot_result(self,scene_id,shot_id,result):
        self.scene(scene_id)["shots"][shot_id]=result; self.save()
    def open_loop(self,scene_id,text,payoff_within=3):
        self.scene(scene_id)["open_loops"].append({"text":text,"payoff_within":payoff_within,"resolved":False}); self.save()
