from __future__ import annotations
import json, hashlib, platform, subprocess, shutil
from pathlib import Path
from datetime import datetime, timezone

def digest(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def build_manifest(output, inputs=None, engines=None, licenses=None, metadata=None):
    output=Path(output)
    return {
      "schema":"harum.provenance/1",
      "created_at":datetime.now(timezone.utc).isoformat(),
      "output":{"path":str(output),"sha256":digest(output) if output.exists() else None},
      "inputs":[{"path":str(Path(x)),"sha256":digest(x) if Path(x).exists() else None} for x in (inputs or [])],
      "engines":engines or [],
      "licenses":licenses or [],
      "environment":{"python":platform.python_version(),"platform":platform.platform()},
      "metadata":metadata or {}
    }

def write_manifest(path, manifest):
    Path(path).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
