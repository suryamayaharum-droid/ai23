from __future__ import annotations
def estimate_shot(duration_s, runtime_factor=1.0, credit_cost=0.0, gpu_minutes=0.0):
    return {
      "duration_s":duration_s,
      "estimated_wall_minutes":round(duration_s*runtime_factor/60,2),
      "credit_cost":round(float(credit_cost),4),
      "gpu_minutes":round(float(gpu_minutes),2)
    }
def scene_total(rows):
    keys=["estimated_wall_minutes","credit_cost","gpu_minutes"]
    return {k:round(sum(float(r.get(k,0)) for r in rows),3) for k in keys}
